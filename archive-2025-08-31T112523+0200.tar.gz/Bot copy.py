from telegram.ext import Updater, CommandHandler

import os

# Lấy token từ biến môi trường (Environment Variables)

TOKEN = os.getenv("TOKEN")

def start(update, context):

    update.message.reply_text("Xin chào 🚀! Bot Telegram đang chạy trên FPS.ms")

updater = Updater(TOKEN, use_context=True)

dp = updater.dispatcher

dp.add_handler(CommandHandler("start", start))

updater.start_polling()

updater.idle()